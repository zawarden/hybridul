#!/usr/bin/env python

import os
import subprocess
import json
from dotenv import load_dotenv

# Load environmental variables from apigee_config.sh
config_file = "apigee_config.sh"

# Check if the file exists
if not os.path.exists(config_file):
    print(f"Error: {config_file} not found. Please run the configuration script first.")
    exit(1)

# Load environment variables from the config file
load_dotenv(dotenv_path=config_file)

# Check if required variables are set
required_variables = ["TOKEN", "ORG_NAME", "RUNTIMETYPE", "ANALYTICS_REGION", "PROJECT_ID", "ENV_GROUP", "DOMAIN"]
missing_variables = [var for var in required_variables if var not in os.environ]

if missing_variables:
    print(f"Error: The following variables are missing: {', '.join(missing_variables)}")
    exit(1)

#curl pentru org creation
# Create the curl command to create the organization
org_curl_command = f'''curl -H "Authorization: Bearer {os.environ['TOKEN']}" \
    -X POST -H "content-type:application/json" \
    -d '{{
        "name":"{os.environ['ORG_NAME']}",
        "runtimeType":"{os.environ['RUNTIMETYPE']}",
        "analyticsRegion":"{os.environ['ANALYTICS_REGION']}"
    }}' \
    "https://apigee.googleapis.com/v1/organizations?parent=projects/{os.environ['PROJECT_ID']}"'''



# Run the organization creation curl command
result_create_org = subprocess.run(["/bin/bash", "-c", org_curl_command], capture_output=True, text=True)

# Check if the response contains an "error" and print the "status" variable value
try:
    response_json = json.loads(result_create_org.stdout)
    
    if 'error' in response_json:
        error_status = response_json['error'].get('status', 'Unknown status')
        print(f"Error creating Organization. Status: {error_status}")
    else:
        print("Organization creation successful.")
except json.JSONDecodeError as e:
    print(f"Error decoding JSON response: {e}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")

#curl pentru env creation
# Create the curl command to create the environment
curl_command_create_env = f'''curl -H "Authorization: Bearer {os.environ['TOKEN']}" \
    -X POST -H "content-type:application/json" \
    -d '{{
        "name": "{os.environ['ENV_NAME']}"
    }}' \
    "https://apigee.googleapis.com/v1/organizations/{os.environ['ORG_NAME']}/environments"'''

# Run the third curl command and capture the output
result_create_env = subprocess.run(["/bin/bash", "-c", curl_command_create_env], capture_output=True, text=True)

# Check if the environment creation was successful
try:
    response_json = json.loads(result_create_env.stdout)
    
    if 'error' in response_json:
        error_status = response_json['error'].get('status', 'Unknown status')
        print(f"Error creating Environment. Status: {error_status}")
    else:
        print("Environment creation successful.")
except json.JSONDecodeError as e:
    print(f"Error decoding JSON response: {e}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")

###########################
#curl pentru org creation
curl_command_create_env_group = f'''curl -H "Authorization: Bearer {os.environ['TOKEN']}" \
    -X POST -H "content-type:application/json" \
    -d '{{
        "name": "{os.environ['ENV_GROUP']}",
        "hostnames":"{os.environ['DOMAIN']}"
    }}' \
    "https://apigee.googleapis.com/v1/organizations/{os.environ['ORG_NAME']}/envgroups"'''

# Run the curl for org creation
result_create_env_group = subprocess.run(["/bin/bash", "-c", curl_command_create_env_group], capture_output=True, text=True)

# Check if the environment group creation was successful
try:
    response_json = json.loads(result_create_env_group.stdout)
    
    if 'error' in response_json:
        error_status = response_json['error'].get('status', 'Unknown status')
        print(f"Error creating Environment Group. Status: {error_status}")
    else:
        print("Environment Group creation successful.")
except json.JSONDecodeError as e:
    print(f"Error decoding JSON response: {e}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")

# curl command to attach environment to group
curl_command_attach_env_to_group = f'''curl -H "Authorization: Bearer {os.environ['TOKEN']}" \
    -X POST -H "content-type:application/json" \
    -d '{{
        "environment": "{os.environ['ENV_NAME']}",
    }}' \
    "https://apigee.googleapis.com/v1/organizations/{os.environ['ORG_NAME']}/envgroups/{os.environ['ENV_GROUP']}/attachments"'''

# Run the curl for attachment
result_attach_env_to_group = subprocess.run(["/bin/bash", "-c", curl_command_attach_env_to_group], capture_output=True, text=True)

# Check if the attachment creation was successful
try:
    response_json = json.loads(result_attach_env_to_group.stdout)
    
    if 'error' in response_json:
        error_status = response_json['error'].get('status', 'Unknown status')
        print(f"Error creating Environment attachment. Status: {error_status}")
    else:
        print("Environment Group attachment successful.")
except json.JSONDecodeError as e:
    print(f"Error decoding JSON response: {e}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")