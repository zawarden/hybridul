#!/usr/bin/env python

import os
import subprocess

# Run gcloud auth print-access-token to set the TOKEN variable
try:
    token_output = subprocess.check_output(["gcloud", "auth", "print-access-token"], text=True).strip()
except subprocess.CalledProcessError as e:
    print(f"Error running 'gcloud auth print-access-token': {e}")
    exit(1)

# Set the TOKEN variable
os.environ["TOKEN"] = token_output

# Prompt user for values
PROJECT_ID = input("Enter your project ID/Name: ")
COMPUTE_REGION = input("Choose a compute region (e.g., us-west1): ")
CLUSTER_NAME = input("Enter the name for your new GKE cluster: ")
ENV_NAME = input("Choose a name for Apigee environment: ")
ENV_GROUP = input("Choose a name for Apigee environment group: ")
DOMAIN = input ("Chose a domain name, PS: if you have a real one it would be cool :): ")
AP_INSTANCE_NAME = input("Chose Apigee Instance name: ")
INGRESS_NAME = input("Chose a name for the Ingress pod, max 17 chars: ")
GOOGLE_ACCOUNT = input("Enter your Google Account Email address: ")

# Set the remaining variables")
CLUSTER_LOCATION = COMPUTE_REGION
ANALYTICS_REGION = COMPUTE_REGION
RUNTIMETYPE = "HYBRID"
POOL_NAME1 = "apigee-data"
POOL_NAME2 = "apigee-runtime"
# Create the content to be appended to .bashrc
bashrc_content = f'''# Start of Apigee Hybrid Configuration
export TOKEN={token_output}
export PROJECT_ID={PROJECT_ID}
export ORG_NAME={PROJECT_ID}
export CLUSTER_NAME={CLUSTER_NAME}
export ENV_NAME={ENV_NAME}
export ENV_GROUP={ENV_GROUP}
export CLUSTER_LOCATION={CLUSTER_LOCATION}
export ANALYTICS_REGION={ANALYTICS_REGION}
export RUNTIMETYPE={RUNTIMETYPE}
export POOL_NAME1={POOL_NAME1}
export POOL_NAME2={POOL_NAME2}
export DOMAIN={DOMAIN}
export COMPUTE_REGION={COMPUTE_REGION}
export AP_INSTANCE_NAME={AP_INSTANCE_NAME}
export INGRESS_NAME={INGRESS_NAME}
export GOOGLE_ACCOUNT={GOOGLE_ACCOUNT}
# End of Apigee Hybrid Configuration
'''

# Write the content to a .sh file
with open('apigee_config.sh', 'w') as sh_file:
    sh_file.write(bashrc_content)

print("Changes saved to 'apigee_config.sh'.")

#Files to run, both bash and python
def run_bash_scripts():
    # Run your Bash scripts using subprocess
    subprocess.run(['bash', 'damdrumulaapi.sh'])

def run_python_scripts():
    # Run your Python scripts using subprocess
    subprocess.run(['python', 'curluri.py'])

def run_bash_scripts():
    # Run your Bash scripts using subprocess
    subprocess.run(['bash', 'gcloudaneala.sh'])

if __name__ == "__main__":
    print("Running Python scripts...")
    run_python_scripts()

    print("Running Bash scripts...")
    run_bash_scripts()

    print("Installation complete.")