#sursa de variabile de scoici
source apigee_config.sh

#Dam si download la arhiva apigee-ului
curl -LO \
    https://storage.googleapis.com/apigee-release/hybrid/apigee-hybrid-setup/1.10.4/apigeectl_linux_64.tar.gz
sleep 5

arhiva=$(ls | grep apigeectl)
haicupath=$(pwd)

tar xvzf $arhiva -C $haicupath
sleep 5
#De aici incolo cream folderele necesare instalarii
mkdir apigee-installation-files
APIGEE_INSTALL=$(pwd)
cd $APIGEE_INSTALL
echo "APIGEE_INSTALL=$APIGEE_INSTALL" >> apigee_config.sh

semuta=$(ls | grep apigeectl_1 | awk '{print $1}')
sleep 5
mv $semuta apigeectl
rm -rf $arhiva
sleep 3
sudo mv apigeectl ./apigee-installation-files
folder_name="apigeectl"
folder_path=$(find /home/ -type d -name "$folder_name")
sleep 3
# Check if the folder was found
if [ -n "$folder_path" ]; then
    echo "Folder found at: $folder_path"
else
    echo "Folder not found."
fi
sleep 2
export APIGEECTL_HOME=$folder_path
echo $APIGEECTL_HOME path pentru apigeectl
echo "APIGEECTL_HOME=$APIGEECTL_HOME" >> apigee_config.sh
sleep 2
parent_directory=$(dirname "$folder_path")
mkdir "$parent_directory/hybrid-files"
sleep 2
folder_name_h="hybrid-files"
folder_path_h=$(find /home/ -type d -name "$folder_name_h")
sleep 2
# Check if the folder was found
if [ -n "$folder_path_h" ]; then
    echo "Folder found at: $folder_path_h"
else
    echo "Folder not found."
fi
sleep 5
export HYBRID_FILES=$folder_path_h
echo $HYBRID_FILES path pentru hybrid files
echo "HYBRID_FILES=$HYBRID_FILES" >> apigee_config.sh
sleep 5
mkdir $HYBRID_FILES/overrides
mkdir $HYBRID_FILES/certs
sleep 2
ln -s $APIGEECTL_HOME/tools $HYBRID_FILES/tools
ln -s $APIGEECTL_HOME/config $HYBRID_FILES/config
ln -s $APIGEECTL_HOME/templates $HYBRID_FILES/templates
ln -s $APIGEECTL_HOME/plugins $HYBRID_FILES/plugins
sleep 2
#creare service account

$HYBRID_FILES/tools/create-service-account --env non-prod --dir $HYBRID_FILES/service-accounts
sleep 5
ls $HYBRID_FILES/service-accounts

#creare certificate

#Create TLS Certificates

openssl req  -nodes -new -x509 -keyout $HYBRID_FILES/certs/keystore_$ENV_GROUP.key -out \
    $HYBRID_FILES/certs/keystore_$ENV_GROUP.pem -subj '/CN='$DOMAIN'' -days 3650

#Check if .pem and .key files have been created 
ls $HYBRID_FILES/certs

#sa cream un cluster zic
gcloud container clusters create $CLUSTER_NAME \
    --project $PROJECT_ID \
    --region $COMPUTE_REGION \
    --release-channel None \
    --machine-type e2-standard-4 \
    --no-enable-autoupgrade \
    --service-account=apigee-non-prod@$PROJECT_ID.iam.gserviceaccount.com \
    --cluster-version 1.28.5-gke.1217000 \
    --release-channel None

echo taking a break, making sure cluster is created
sleep 30

#Cream noduri 1
gcloud container node-pools create $POOL_NAME1 \
    --project $PROJECT_ID \
    --cluster $CLUSTER_NAME \
    --region $COMPUTE_REGION \
    --machine-type e2-standard-4 \
    --node-version 1.28.5-gke.1217000

#Cream noduri 2
gcloud container node-pools create $POOL_NAME2 \
    --project $PROJECT_ID \
    --cluster $CLUSTER_NAME \
    --region $COMPUTE_REGION \
    --machine-type e2-standard-4 \
    --node-version 1.28.5-gke.1217000

#Stergem noduri default
gcloud container node-pools delete default-pool --quiet \
    --project $PROJECT_ID \
    --cluster $CLUSTER_NAME \
    --region $COMPUTE_REGION
#Cream un yaml pentru un element de storage permanent in clusterul GKE
echo "
---
kind: StorageClass
apiVersion: storage.k8s.io/v1
metadata:
  name: "apigee-sc"
provisioner: kubernetes.io/gce-pd
parameters:
  type: pd-ssd
  replication-type: none
volumeBindingMode: WaitForFirstConsumer
allowVolumeExpansion: true" > storageclass.yaml
#Ii dam access sa poata fi rulat
chmod +x storageclass.yaml
#Ii dam apply/il cream
kubectl apply -f storageclass.yaml
sleep 5
#Modificam defaultul prin a scoate "default" de pe default
kubectl patch storageclass standard-rwo \
-p '{"metadata": {"annotations":{"storageclass.kubernetes.io/is-default-class":"false"}}}'
sleep 2
#Applicam noul element storage ca si default
kubectl patch storageclass apigee-sc \
-p '{"metadata": {"annotations":{"storageclass.kubernetes.io/is-default-class":"true"}}}'
sleep 2
#Verificam si noi daca a mers ouput o sa fie "apigee-sc(default)"
kubectl get sc | grep apigee-sc | awk '{print $1, $2}'
sleep 2

#Instalam un manager de certificate, care binenteles sunt niste poduri si service-uri
kubectl apply --validate=false -f https://github.com/jetstack/cert-manager/releases/download/v1.10.1/cert-manager.yaml
sleep 5
kubectl get all -n cert-manager -o wide
sleep 2 


#Cream un Overrides.yaml baban.
#Exista mai multe configuration files "config.yaml" locate in multiple locatii din folderele de instalare.
export CERT_NAME=$HYBRID_FILES/certs/keystore_$ENV_GROUP.key
export KEY_NAME=$HYBRID_FILES/certs/keystore_$ENV_GROUP.pem
export SERVICE_ACCOUNT_PATH=./service-accounts/$PROJECT_ID-apigee-non-prod.json
echo path to service account is $PROJECT_ID-apigee-non-prod.json


echo "
gcp:
  region: $COMPUTE_REGION
  projectID: wave3-dorualexandru-apigee-h

k8sCluster:
  name: $CLUSTER_NAME
  region: us-west1 # Must be the closest Google Cloud region to your cluster.
org: wave3-dorualexandru-apigee-h

instanceID: $AP_INSTANCE_NAME

cassandra:
  replicaCount: 1
    # Use 1 for non-prod or "demo" installations and multiples of 3 for production.
    # See Configure Cassandra for production for guidelines.
  hostNetwork: false
    # Set to false for single region installations and multi-region installations
    # with connectivity between pods in different clusters, for example GKE installations.
    # Set to true  for multi-region installations with no communication between
    # pods in different clusters, for example GKE On-prem, GKE on AWS, Anthos on bare metal,
    # AKS, EKS, and OpenShift installations.
    # See Multi-region deployment: Prerequisites

virtualhosts:
- name: $ENV_GROUP
  selector:
    app: apigee-ingressgateway
    ingress_name: $INGRESS_NAME
  sslCertPath: $CERT_NAME
  sslKeyPath: $KEY_NAME

ingressGateways:
- name: $INGRESS_NAME # maximum 17 characters.
  replicaCountMin: 2
  replicaCountMax: 10

envs:
- name: $ENV_NAME
  serviceAccountPaths:
    synchronizer: "$SERVICE_ACCOUNT_PATH"
      # For example: "$SERVICE_ACCOUNT_PATH"
    udca: "$SERVICE_ACCOUNT_PATH"
    runtime: "$SERVICE_ACCOUNT_PATH"


mart:
  serviceAccountPath: "$SERVICE_ACCOUNT_PATH"

connectAgent:
  serviceAccountPath: "$SERVICE_ACCOUNT_PATH"

metrics:
  serviceAccountPath: "$SERVICE_ACCOUNT_PATH"

udca:
  serviceAccountPath: "$SERVICE_ACCOUNT_PATH"

watcher:
  serviceAccountPath: "$SERVICE_ACCOUNT_PATH"

logger:
  enabled: false
        # Set to false to disable logger for GKE installations.
        # Set to true for all platforms other than GKE.
        # See apigee-logger in Service accounts and roles used by hybrid components.
  serviceAccountPath: "$SERVICE_ACCOUNT_PATH"" > $HYBRID_FILES/overrides/overrides.yaml

#Enable synchronizer access
#You need roles/apigee.admin assigned on your Google account in the GCP Project if more info needed user "https://cloud.google.com/apigee/docs/hybrid/v1.10/install-enable-synchronizer-access"
#Making sure we have the roles on our Google Account 
gcloud projects get-iam-policy ${PROJECT_ID}  \
  --flatten="bindings[].members" \
  --format='table(bindings.role)' \
  --filter="bindings.members:${GOOGLE_ACCOUNT}"

#Adaugam rolul
gcloud projects add-iam-policy-binding ${PROJECT_ID} \
  --member user:${GOOGLE_ACCOUNT} \
  --role roles/apigee.admin

#Mai luam un token sa fim siguri ca e fresh 
export TOKEN=$(gcloud auth print-access-token)

gcloud iam service-accounts list --project ${PROJECT_ID} --filter "apigee-non-prod"
#Getting access token for the service account used for the cluster and setting synchronizer to use it

curl -X POST -H "Authorization: Bearer ${TOKEN}" \
  -H "Content-Type:application/json" \
  "https://apigee.googleapis.com/v1/organizations/${ORG_NAME}:setSyncAuthorization" \
   -d '{"identities":["'"serviceAccount:apigee-non-prod@${ORG_NAME}.iam.gserviceaccount.com"'"]}'

#Verify the account was set
curl -X GET -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type:application/json" \
  "https://apigee.googleapis.com/v1/organizations/${ORG_NAME}:getSyncAuthorization"

#Verificare cluster
kubectl config current-context

gcloud container clusters get-credentials $CLUSTER_NAME \
--region $CLUSTER_LOCATION \
--project $PROJECT_ID

mkdir $HYBRID_FILES/cluster-check
echo "
apiVersion: v1
kind: ServiceAccount
metadata:
  name: apigee-k8s-cluster-ready-check
---
apiVersion: batch/v1
kind: Job
metadata:
  name: apigee-k8s-cluster-ready-check
spec:
  template:
    spec:
      hostNetwork: true
      serviceAccountName: apigee-k8s-cluster-ready-check
      containers:
        - name: manager
          image: gcr.io/apigee-release/hybrid/apigee-operators:1.10.0
          command:
            - /manager
          args:
          - --k8s-cluster-ready-check
          env:
          - name: POD_IP
            valueFrom:
              fieldRef:
                fieldPath: status.podIP
          securityContext:
            runAsGroup: 998
            runAsNonRoot: true
            runAsUser: 999
      restartPolicy: Never
  backoffLimit: 1" > $HYBRID_FILES/cluster-check/apigee-k8s-cluster-ready-check.yaml
sleep 25

kubectl apply -f $HYBRID_FILES/cluster-check/apigee-k8s-cluster-ready-check.yaml
sleep 5
kubectl get jobs apigee-k8s-cluster-ready-check
sleep 5
#Cleaning up 
kubectl delete -f $HYBRID_FILES/cluster-check/apigee-k8s-cluster-ready-check.yaml

#Installing Hybrid Runtime, files.pods that are used to install the product
cd $HYBRID_FILES
kubectl config current-context
sleep 2
gcloud container clusters get-credentials $CLUSTER_NAME \
--region $CLUSTER_LOCATION \
--project $PROJECT_ID
sleep 2
${APIGEECTL_HOME}/apigeectl init -f overrides/overrides.yaml --dry-run=client
sleep 5
${APIGEECTL_HOME}/apigeectl init -f overrides/overrides.yaml
sleep 20
${APIGEECTL_HOME}/apigeectl check-ready -f overrides/overrides.yaml
sleep 5
kubectl get pods -n apigee-system
sleep 1
kubectl get pods -n apigee
sleep 1

export CERT_NAME=$HYBRID_FILES/certs/keystore_$ENV_GROUP.key
export KEY_NAME=$HYBRID_FILES/certs/keystore_$ENV_GROUP.pem

${APIGEECTL_HOME}/apigeectl apply -f overrides/overrides.yaml --dry-run=client
sleep 5
${APIGEECTL_HOME}/apigeectl apply -f overrides/overrides.yaml
echo "Hai ca mai e putin, timeout 4 min"
sleep 240
${APIGEECTL_HOME}/apigeectl check-ready -f overrides/overrides.yaml