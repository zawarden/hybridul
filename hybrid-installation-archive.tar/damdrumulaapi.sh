gcloud services enable apigee.googleapis.com \
    servicenetworking.googleapis.com \
    compute.googleapis.com \
    cloudkms.googleapis.com --project=$PROJECT_ID

/usr/bin/python3.9 -m pip install python-dotenv
/usr/bin/python2.7 -m pip install python-dotenv
/usr/bin/python -m pip install python-dotenv